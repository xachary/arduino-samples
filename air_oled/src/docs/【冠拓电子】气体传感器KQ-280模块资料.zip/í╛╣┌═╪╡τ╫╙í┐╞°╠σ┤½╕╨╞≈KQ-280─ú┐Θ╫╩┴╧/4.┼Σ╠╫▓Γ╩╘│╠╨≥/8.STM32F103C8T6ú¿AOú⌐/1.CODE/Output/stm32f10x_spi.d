..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\src\stm32f10x_spi.c
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_spi.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\CMSIS\stm32f10x.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\CMSIS\core_cm3.h
..\..\output\stm32f10x_spi.o: D:\Program Files (x86)\Keil\ARM\ARMCC\Bin\..\include\stdint.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\CMSIS\system_stm32f10x.h
..\..\output\stm32f10x_spi.o: ..\..\User\stm32f10x_conf.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_adc.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\CMSIS\stm32f10x.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_dma.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_gpio.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_rcc.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_tim.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\stm32f10x_usart.h
..\..\output\stm32f10x_spi.o: ..\..\Libraries\FWlib\inc\misc.h
