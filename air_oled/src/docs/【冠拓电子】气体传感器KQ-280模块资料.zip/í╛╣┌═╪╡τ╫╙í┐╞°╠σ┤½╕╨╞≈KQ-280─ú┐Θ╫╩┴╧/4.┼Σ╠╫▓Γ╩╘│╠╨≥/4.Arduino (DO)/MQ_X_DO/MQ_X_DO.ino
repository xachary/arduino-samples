/***************************************************
* MQ系列传感器 
* ****************************************************
* This example is to get liquid level

* All above must be included in any redistribution
* ****************************************************/
int MQ_X_level=0;
void setup() {
 Serial.begin(9600);
 pinMode(5,INPUT);
}

void loop() {
MQ_X_level=digitalRead(5);
Serial.print("MQ_X_level= ");Serial.println(MQ_X_level,DEC);
delay(500);
} 
